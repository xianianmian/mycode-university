<template>
  <div id="app">
    <Home
    :initValue="slider1.sliderInit"
    :titile="slider1.marginText"
    @myValue1="backValue1"
    ></Home>
    <About
    :initValue2="slider2.sliderInit"
    @myValue2="backValue2"
    ></About>
  </div>
</template>

<style>

</style>
<script>
import Home from '../src/views/Home.vue'
import About from '../src/views/About.vue'
export default {
  components:{Home,About},
  data(){
    return{
      slider1:{
        sliderInit:50,
        marginText:'边距一号',
      },
      slider2:{
        sliderInit:20,
      }
    }
  },
  methods:{
    backValue1(value,biaoti){
      this.slider1.sliderInit=value;
      this.slider1.marginText=biaoti;
      console.log(this.slider1.sliderInit);
      console.log(this.slider1.marginText);
    },
    backValue2(zi){
      this.slider2.sliderInit=zi;
      console.log(this.slider2.sliderInit);
    }
  }

}
</script>
